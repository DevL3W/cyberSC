const form = document.getElementById('loginForm');
const errorBox = document.getElementById('error');
const submit = document.getElementById('submit');

if (Api.getToken()) {
  Splash.text('Abriendo su sesión…');
  window.location.href = 'dashboard.html';
} else {
  window.addEventListener('load', () => Splash.hide());
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  errorBox.classList.add('d-none');
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  if (!username || !password) {
    errorBox.textContent = 'Escriba el nombre de su sesión y su contraseña.';
    errorBox.classList.remove('d-none');
    return;
  }
  submit.disabled = true;
  submit.textContent = 'Iniciando sesión…';
  try {
    const res = await Api.post('/api/auth/login', { username, password });
    Api.setToken(res.token);
    window.location.href = 'dashboard.html';
  } catch (err) {
    errorBox.textContent = err.message;
    errorBox.classList.remove('d-none');
    submit.disabled = false;
    submit.textContent = 'Iniciar sesión';
  }
});

// Mostrar el enlace "Crear cuenta" solo si el registro está activado
Api.get('/api/auth/config')
  .then((c) => { if (c && c.registrationEnabled) document.getElementById('registerLink').classList.remove('d-none'); })
  .catch(() => {});
